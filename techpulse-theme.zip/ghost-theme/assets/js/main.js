// Navbar scroll effect
const navbar = document.getElementById('navbar');
window.addEventListener('scroll', () => {
  if (window.scrollY > 50) {
    navbar.classList.add('scrolled');
  } else {
    navbar.classList.remove('scrolled');
  }
});

// Search toggle
function toggleSearch() {
  const overlay = document.getElementById('searchOverlay');
  const input = document.getElementById('searchInput');
  overlay.classList.toggle('active');
  if (overlay.classList.contains('active')) {
    setTimeout(() => input.focus(), 100);
  }
}

// Close search on Escape
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') {
    document.getElementById('searchOverlay').classList.remove('active');
  }
});

// Animate posts on scroll
const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.style.opacity = '1';
      entry.target.style.transform = 'translateY(0)';
    }
  });
}, { threshold: 0.1 });

document.querySelectorAll('.post-card').forEach(card => {
  observer.observe(card);
});

// Add copy button to code blocks
document.querySelectorAll('pre').forEach(block => {
  const btn = document.createElement('button');
  btn.textContent = 'Copy';
  btn.style.cssText = `
    position: absolute;
    top: 12px;
    right: 12px;
    background: rgba(108, 99, 255, 0.2);
    border: 1px solid rgba(108, 99, 255, 0.4);
    color: #6c63ff;
    padding: 4px 10px;
    border-radius: 6px;
    font-size: 0.75rem;
    cursor: pointer;
    font-family: inherit;
    transition: all 0.2s;
  `;
  btn.addEventListener('click', () => {
    navigator.clipboard.writeText(block.querySelector('code')?.textContent || block.textContent);
    btn.textContent = 'Copied!';
    btn.style.color = '#00d4aa';
    setTimeout(() => {
      btn.textContent = 'Copy';
      btn.style.color = '#6c63ff';
    }, 2000);
  });
  block.appendChild(btn);
});

// Smooth reading progress bar
const progressBar = document.createElement('div');
progressBar.style.cssText = `
  position: fixed;
  top: 0;
  left: 0;
  height: 3px;
  background: linear-gradient(90deg, #6c63ff, #ff6b9d);
  z-index: 999;
  width: 0%;
  transition: width 0.1s;
`;
document.body.appendChild(progressBar);

window.addEventListener('scroll', () => {
  const scrollTop = window.scrollY;
  const docHeight = document.documentElement.scrollHeight - window.innerHeight;
  const progress = (scrollTop / docHeight) * 100;
  progressBar.style.width = progress + '%';
});
